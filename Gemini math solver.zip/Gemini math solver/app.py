import base64
from PIL import Image
import pytesseract
import re
import io
import streamlit as st
from google.generativeai.types.generation_types import StopCandidateException
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import HumanMessage
from pdf2image import convert_from_bytes

# API Key (ensure it's stored securely in practice)
api = 'AIzaSyAAlues6baEIdIf-cPpXGqIm4xOqwcs6ak'

# Path to Tesseract executable (required on Windows)
# Uncomment and provide the correct path if you're on Windows
# pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# OCR for Images
def ocr_image(image):
    """Extract text from an image using pytesseract."""
    text = pytesseract.image_to_string(image)
    return text

# OCR for PDFs
def ocr_pdf(pdf_file):
    """Convert PDF pages to images and extract text from each page using pytesseract."""
    images = convert_from_bytes(pdf_file.read())
    text = ""
    for page_image in images:
        text += pytesseract.image_to_string(page_image)
    return text

# Gemini AI model function
def gemini(input_text="", image=None):
    # Initialize the model
    model = ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=api)
    temp = f"You are a teacher. You should clear all my math doubts.\n\nHere is my doubt: {input_text}"

    try:
        prompt = HumanMessage(content=temp)

        # Call the Langchain model to generate a response
        response = model.invoke([prompt])

    except StopCandidateException as e:
        e_str = str(e)
        text_pattern = r'text:\s*"([^*]*)"'
        matches = re.findall(text_pattern, e_str)
        for match in matches:
            return match

    return response.content

def main():
    # Set animated background
    page_bg_img = '''
    <style>
    body {
        background: linear-gradient(45deg, #ff6b6b, #f7d794, #00d2d3, #54a0ff);
        background-size: 600% 600%;
        animation: gradientAnimation 15s ease infinite;
    }

    @keyframes gradientAnimation {
        0% {background-position: 0% 50%;}
        50% {background-position: 100% 50%;}
        100% {background-position: 0% 50%;}
    }

    .stButton button {
        background-color: #ff6b6b;
        color: white;
        border-radius: 10px;
        transition: transform 0.2s ease;
    }

    .stButton button:hover {
        background-color: #54a0ff;
        transform: scale(1.1);
    }

    .stFileUploader {
        animation: fadeIn 3s;
    }

    .stTextArea {
        animation: fadeIn 2s;
    }

    @keyframes fadeIn {
        0% {opacity: 0;}
        100% {opacity: 1;}
    }

    </style>
    '''
    st.markdown(page_bg_img, unsafe_allow_html=True)

    # Title and description
    st.title("Gemini Maths Solver with OCR 🧠📚")
    st.write(
        "Welcome to the **Gemini Maths Solver**! Upload an image or PDF of your math problem, or type your question below."
    )

    st.sidebar.title("Instructions 📖")
    st.sidebar.write(
        """
        1. **Upload Image/PDF**: Upload an image or PDF of your math problem.
        2. **Enter Question**: Type your math-related question in the input box.
        3. **Submit**: Click on the submit button to get your answer!
        """
    )

    # Feedback storage in session state
    if "feedback_list" not in st.session_state:
        st.session_state.feedback_list = []

    # Feedback form in the sidebar
    st.sidebar.write("### Feedback 💬")
    feedback = st.sidebar.text_area("Share your thoughts or feedback with us:")
    feedback_button = st.sidebar.button("Submit Feedback")

    if feedback_button and feedback:
        st.session_state.feedback_list.append(feedback)  # Store feedback
        st.sidebar.write("Thank you for your feedback!")
        st.sidebar.write("### Previous Feedback:")
        for f in st.session_state.feedback_list:
            st.sidebar.write(f"- {f}")

    # Initialize chat messages in session state
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display past messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    try:
        # Input form for image and text prompt
        with st.form(key="input_form"):
            st.write("## Upload an Image or PDF of Your Problem 📷📄")
            col1, col2 = st.columns([2, 3])
            with col1:
                image = st.file_uploader("Upload an image or PDF (optional):", type=["jpg", "jpeg", "png", "pdf"])
            with col2:
                prompt = st.text_area("Or type your math question:", height=100)

            # Submit button
            submit_button = st.form_submit_button(label="Submit 🚀")

        # Process user input
        if submit_button and (prompt or image):
            st.session_state.messages.append({"role": "user", "content": prompt if prompt else "Uploaded image or PDF."})

            with st.chat_message("user"):
                if image:
                    st.write(f"Uploaded file: {image.name}")
                    if image.type == "application/pdf":
                        # Handle PDF: OCR the PDF
                        extracted_text = ocr_pdf(image)
                        st.write("Extracted text from PDF:", extracted_text)
                        response = gemini(input_text=extracted_text)
                    else:
                        # Handle Image: OCR the image
                        img = Image.open(image)
                        extracted_text = ocr_image(img)
                        st.write("Extracted text from image:", extracted_text)
                        response = gemini(input_text=extracted_text)
                else:
                    response = gemini(input_text=prompt)

                st.markdown(response)
                st.session_state.messages.append({"role": "assistant", "content": response})

    except Exception as e:
        st.error(f"An error occurred: {e}")

# Run the app
if __name__ == "__main__":
    main()
